package br.com.helpconnect.socialConnect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SocialConnectApplicationTests {

	@Test
	void contextLoads() {
	}

}
